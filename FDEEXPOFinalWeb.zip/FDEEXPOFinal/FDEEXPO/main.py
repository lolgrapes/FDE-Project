from flask import Flask, jsonify, render_template
import pandas as pd
import requests

# ----------------------------
# 🔹 Initialize Flask App
# ----------------------------
app = Flask(__name__, template_folder='.')

# ----------------------------
# 🔹 Function: Fetch Real-Time Last.fm Data
# ----------------------------
def fetch_lastfm_data(api_key):
    """Fetch real-time global track data from Last.fm"""
    all_tracks = []

    try:
        url = "http://ws.audioscrobbler.com/2.0/"
        params = {
            'method': 'chart.gettoptracks',
            'api_key': api_key,
            'format': 'json',
            'limit': 50
        }

        print("Fetching real-time global music data from Last.fm...")
        response = requests.get(url, params=params)
        response.raise_for_status()

        data = response.json()
        tracks = data['tracks']['track']

        for rank, track in enumerate(tracks, 1):
            track_data = {
                'rank': rank,
                'name': track.get('name', 'Unknown'),
                'artist': track['artist'].get('name', 'Unknown'),
                'listeners': int(track.get('listeners', 0)),
                'playcount': int(track.get('playcount', 0)),
                'chart': 'Last.fm Global Chart'
            }
            all_tracks.append(track_data)

        return pd.DataFrame(all_tracks)

    except requests.exceptions.RequestException as e:
        print(f"Error fetching data from Last.fm: {str(e)}")
        raise

# ----------------------------
# 🔹 Function: Wrapper for Fetching Chart Data
# ----------------------------
def fetch_chart_data():
    """Fetch chart data using Last.fm API"""
    api_key = "887d128206bb51c4855657f1cb12a241"  # Replace with your actual Last.fm API key
    return fetch_lastfm_data(api_key)

# ----------------------------
# 🔹 Flask Routes
# ----------------------------

@app.route('/')
def home():
    """Serve the main frontend page"""
    return render_template('index.html')

@app.route('/api/lastfm')
def api_lastfm():
    """Return the chart data as JSON (for frontend fetch)"""
    try:
        df = fetch_chart_data()
        return jsonify(df.to_dict(orient='records'))
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ----------------------------
# 🔹 Local CLI Mode (Optional)
# ----------------------------
def cli_mode():
    """Optional: Run interactive CLI-based analysis (same as your original logic)"""
    try:
        print("Loading real-time global music data...")
        df = fetch_chart_data()

        while True:
            columns_desc = {
                'rank': 'Chart Position',
                'name': 'Track Name',
                'artist': 'Artist Name',
                'listeners': 'Number of Listeners',
                'playcount': 'Total Times Played',
                'chart': 'Chart Name'
            }

            print("\nHere are the columns you can analyze:")
            print("=====================================")
            for idx, (col, desc) in enumerate(columns_desc.items()):
                print(f"{idx}: {col} - {desc}")
            print("=====================================\n")

            col_num = input("Enter column number to analyze (or 'q' to quit): ")
            if col_num.lower() == 'q':
                print("Thank you for using the music data analyzer!")
                break

            try:
                col_num = int(col_num)
                analysis_col = list(columns_desc.keys())[col_num]
            except (ValueError, IndexError):
                print(f"Invalid choice. Please enter a number between 0 and {len(columns_desc)-1}")
                continue

            top_n_input = input(f"\nHow many top '{analysis_col}' categories do you want to see? (default 10): ")
            try:
                top_n = int(top_n_input)
            except ValueError:
                top_n = 10

            value_counts = df[analysis_col].value_counts().head(top_n)
            print(f"\nTop {top_n} '{analysis_col}' categories:")
            print(value_counts)

            # Plot pie chart
            import matplotlib.pyplot as plt
            plt.figure(figsize=(12, 8))
            plt.pie(value_counts, labels=value_counts.index, autopct='%1.1f%%')
            plt.title(f"Distribution of {analysis_col}")

            plt.ion()
            plt.show()
            print("\nClose the plot window to continue...")

            while plt.get_fignums():
                plt.pause(0.1)
            plt.close('all')

    except Exception as e:
        print(f"Error: {str(e)}")

# ----------------------------
# 🔹 Entry Point
# ----------------------------
if __name__ == "__main__":
    mode = input("Enter mode ('web' for Flask app or 'cli' for command-line): ").strip().lower()
    if mode == 'cli':
        cli_mode()
    else:
        print("Starting Flask server... Visit http://127.0.0.1:5000 in your browser.")
        app.run(debug=True)
